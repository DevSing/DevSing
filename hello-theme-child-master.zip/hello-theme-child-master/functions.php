<?php
/**
 * Theme functions and definitions.
 *
 * For additional information on potential customization options,
 * read the developers' documentation:
 *
 * https://developers.elementor.com/docs/hello-elementor-theme/
 *
 * @package HelloElementorChild
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

define( 'HELLO_ELEMENTOR_CHILD_VERSION', '2.0.0' );

/**
 * Load child theme scripts & styles.
 *
 * @return void
 */
function hello_elementor_child_scripts_styles() {

	wp_enqueue_style(
		'hello-elementor-child-style',
		get_stylesheet_directory_uri() . '/style.css',
		[
			'hello-elementor-theme-style',
		],
		HELLO_ELEMENTOR_CHILD_VERSION
	);

}
add_action( 'wp_enqueue_scripts', 'hello_elementor_child_scripts_styles', 20 );


// Add a new user role called 'webadmin'
function add_webadmin_role() {
    add_role(
        'webadmin',
        __('Web Administrator'),
        array(
            'read' => true, // Allow the role to read posts and pages
            'edit_posts' => true, // Allow the role to edit posts
            'delete_posts' => true, // Allow the role to delete posts
            // Add more capabilities as needed
        )
    );
}
add_action('init', 'add_webadmin_role');


// Redirect 'webadmin' role users to a custom dashboard page
function custom_webadmin_redirect($redirect_to, $request, $user) {
    // Check if the user has the 'webadmin' role
    if (isset($user->roles) && is_array($user->roles) && in_array('webadmin', $user->roles)) {
        // Redirect to the custom dashboard page
        return home_url('/user-dashboard');
    }
    // For other users, return the default redirect URL
    return $redirect_to;
}
add_filter('login_redirect', 'custom_webadmin_redirect', 10, 3);


// Enqueue custom CSS for login page
function custom_login_css() {
    wp_enqueue_style('custom-login-css', get_stylesheet_directory_uri() . '/custom-login.css');
}
add_action('login_enqueue_scripts', 'custom_login_css');


// Hide toolbar for users with 'webadmin' role
function hide_admin_bar_for_webadmin() {
    if (is_user_logged_in() && current_user_can('webadmin')) {
        return false;
    }
    return true;
}
add_filter('show_admin_bar', 'hide_admin_bar_for_webadmin');