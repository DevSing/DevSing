document.addEventListener('DOMContentLoaded', function () {
    const newsGrid = document.querySelector('.news-grid');
    const singleNews = document.querySelector('.single-news');

    // Sample data for news articles
    const articles = [
        { title: 'Article 1', content: 'Lorem ipsum...', category: 'Technology', image: 'image1.jpg', permalink: 'article-1', tags: ['Tech', 'News'] },
        { title: 'Article 2', content: 'Lorem ipsum...', category: 'Travel', image: 'image2.jpg', permalink: 'article-2', tags: ['Travel', 'Adventure'] },
        // Add more articles as needed
    ];

    // Function to display articles in grid
    function displayArticles() {
        articles.forEach(article => {
            const articleBox = document.createElement('div');
            articleBox.classList.add('news-box');
            articleBox.innerHTML = `
                <img src="${article.image}" alt="${article.title}">
                <h3>${article.title}</h3>
                <p>${article.category}</p>
            `;
            articleBox.addEventListener('click', () => showSingleNews(article));
            newsGrid.appendChild(articleBox);
        });
    }

    // Function to show single news page
    function showSingleNews(article) {
        singleNews.innerHTML = `
            <img src="${article.image}" alt="${article.title}">
            <h2>${article.title}</h2>
            <p>${article.content}</p>
            <p>Category: ${article.category}</p>
            <p>Tags: ${article.tags.join(', ')}</p>
        `;
        singleNews.classList.add('active');
        newsGrid.style.display = 'none';
    }

    // Display articles when the page loads
    displayArticles();
});
