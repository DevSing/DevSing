<?php
/**
 * Enteroverse blank Theme functions and definitions.
 * This theme is developed by DevP.
 */

// Enqueue styles and scripts
function entroverse_enqueue_styles() {
    wp_enqueue_style('entroverse-style', get_stylesheet_uri());
}
add_action('wp_enqueue_scripts', 'entroverse_enqueue_styles');

function entroverse_enqueue_scripts() {
    wp_enqueue_script('entroverse-script', get_template_directory_uri() . '/script.js', array('jquery'), null, true);
}
add_action('wp_enqueue_scripts', 'entroverse_enqueue_scripts');

// Add theme support for basic features
function my_blank_theme_setup() {
    add_theme_support( 'title-tag' );
    add_theme_support( 'post-thumbnails' );
    add_theme_support( 'html5', array( 'comment-list', 'comment-form', 'gallery', 'caption' ) );
    add_theme_support( 'align-wide' );
}
add_action( 'after_setup_theme', 'my_blank_theme_setup' );
?>