</main>

<!-- Add widgets areas if needed -->
<aside>
    <!-- Add your custom widgets here -->
</aside>
</div>

<!-- Add your custom JavaScript code here -->
<?php wp_footer(); ?>
</body>
</html>