
<?php
/**
 * The main template file
 *
 * This theme is blank based theme for developer.
 * Use this theme and start doing custom code.
 * do not forget to give me review or feedback.
 *
 * @link https://developer.wordpress.org/themes/basics/template-hierarchy/
 *
 * @package Enteroverse developed by DevP
 */
if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}
get_header();

if ( have_posts() ) {
    while ( have_posts() ) {
        the_post();

        // Display the post content
        the_title( '<h1>', '</h1>' );
        the_content();

    }
} else {
    // Display a message when no posts are found
    echo '<p>No posts found</p>';
}

get_footer();