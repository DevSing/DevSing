<?php
/*
Plugin Name: All Page URL
Plugin URI: http://www.princekumar.in/all-page-url
Description: A plugin to show all page URLs, post URLs, and category URLs in a WordPress website with export options.
Version: 1.1
Author: DevP
Author URI: http://www.princekumar.in
License: GPL2
*/

// Prevent direct access
if (!defined('ABSPATH')) {
    exit;
}

// Enqueue plugin styles
function all_page_url_enqueue_styles() {
    wp_enqueue_style('all-page-url-styles', plugin_dir_url(__FILE__) . 'style.css');
}
add_action('admin_enqueue_scripts', 'all_page_url_enqueue_styles');

// Register shortcode to display all URLs
function all_page_url_display_all_urls() {
    ob_start();

    // Fetch all published pages
    $pages = get_pages(array('post_status' => 'publish'));
    $posts = get_posts(array('post_status' => 'publish'));
    $categories = get_categories();

    ?>
    <h2>Pages</h2>
    <table>
        <thead>
            <tr>
                <th>S.No</th>
                <th>Publish Date</th>
                <th>Page ID</th>
                <th>Title</th>
                <th>Page URL</th>
            </tr>
        </thead>
        <tbody>
            <?php
            $i = 1;
            foreach ($pages as $page) {
                echo '<tr>';
                echo '<td>' . $i++ . '</td>';
                echo '<td>' . $page->post_date . '</td>';
                echo '<td>' . $page->ID . '</td>';
                echo '<td>' . $page->post_title . '</td>';
                echo '<td>' . get_permalink($page->ID) . '</td>';
                echo '</tr>';
            }
            ?>
        </tbody>
    </table>

    <h2>Posts</h2>
    <table>
        <thead>
            <tr>
                <th>S.No</th>
                <th>Publish Date</th>
                <th>Post ID</th>
                <th>Title</th>
                <th>Post URL</th>
            </tr>
        </thead>
        <tbody>
            <?php
            $i = 1;
            foreach ($posts as $post) {
                echo '<tr>';
                echo '<td>' . $i++ . '</td>';
                echo '<td>' . $post->post_date . '</td>';
                echo '<td>' . $post->ID . '</td>';
                echo '<td>' . $post->post_title . '</td>';
                echo '<td>' . get_permalink($post->ID) . '</td>';
                echo '</tr>';
            }
            ?>
        </tbody>
    </table>

    <h2>Categories</h2>
    <table>
        <thead>
            <tr>
                <th>S.No</th>
                <th>Category ID</th>
                <th>Title</th>
                <th>Category URL</th>
            </tr>
        </thead>
        <tbody>
            <?php
            $i = 1;
            foreach ($categories as $category) {
                echo '<tr>';
                echo '<td>' . $i++ . '</td>';
                echo '<td>' . $category->term_id . '</td>';
                echo '<td>' . $category->name . '</td>';
                echo '<td>' . get_category_link($category->term_id) . '</td>';
                echo '</tr>';
            }
            ?>
        </tbody>
    </table>

    <div class="export-buttons">
        <button onclick="exportTableToCSV('pages.csv', 'table:nth-of-type(1)')">Export Pages to CSV</button>
        <button onclick="exportTableToCSV('posts.csv', 'table:nth-of-type(2)')">Export Posts to CSV</button>
        <button onclick="exportTableToCSV('categories.csv', 'table:nth-of-type(3)')">Export Categories to CSV</button>
    </div>

    <script>
    function downloadCSV(csv, filename) {
        var csvFile;
        var downloadLink;

        // CSV file
        csvFile = new Blob([csv], { type: "text/csv" });

        // Download link
        downloadLink = document.createElement("a");

        // File name
        downloadLink.download = filename;

        // Create a link to the file
        downloadLink.href = window.URL.createObjectURL(csvFile);

        // Hide download link
        downloadLink.style.display = "none";

        // Add the link to DOM
        document.body.appendChild(downloadLink);

        // Click download link
        downloadLink.click();
    }

    function exportTableToCSV(filename, tableSelector) {
        var csv = [];
        var rows = document.querySelectorAll(tableSelector + " tr");

        for (var i = 0; i < rows.length; i++) {
            var row = [], cols = rows[i].querySelectorAll("td, th");

            for (var j = 0; j < cols.length; j++) 
                row.push(cols[j].innerText);

            csv.push(row.join(","));        
        }

        // Download CSV file
        downloadCSV(csv.join("\n"), filename);
    }
    </script>
    <?php

    return ob_get_clean();
}
add_shortcode('show_all_urls', 'all_page_url_display_all_urls');

// Add a menu item in the admin
function all_page_url_add_admin_menu() {
    add_menu_page(
        'Show All URLs',
        'Show All URLs',
        'manage_options',
        'all-page-url',
        'all_page_url_admin_page'
    );
}
add_action('admin_menu', 'all_page_url_add_admin_menu');

// Admin page content
function all_page_url_admin_page() {
    echo '<div class="wrap">';
    echo '<h1>All URLs</h1>';
    echo do_shortcode('[show_all_urls]');
    echo '</div>';
}
